# UNIVERSE_MERSENNE_CORE Verification Report (diagnostics-only)

- created_utc: 2026-01-28T01:52:22.421222+00:00
- json: `C:\Users\User\Downloads\RUTGERS\verification\_quarantine_overfit\_duplicate_verification_tree\verification\_automation\_outputs\universe_mersenne_core\UNIVERSE_MERSENNE_CORE__20260109_102759Z.json`
- csv: `C:\Users\User\Downloads\RUTGERS\verification\_quarantine_overfit\_duplicate_verification_tree\verification\_automation\_outputs\universe_mersenne_core\UNIVERSE_MERSENNE_CORE__20260109_102729Z.csv`
- json_sha256: `be58587f57ad88c157831cb73adc7d110d86383ce8c01a8200dc2f5598eb2e73`
- csv_sha256: `92523656350dab4ce6014c80ae2a9ad4a8d6c1e5bfb5f29ac2ac1524ed6e7cb8`

## Summary

- schema: `universe_mersenne_core_v1`
- config: n_start=1, n_end=260000, csv_stride=200
- csv: n_min=1, n_max=259801, stride_mode=200
- constants_used: K=0.03125, T=1.583630453357918, DIELECTRIC_CONSTANT=12.13
- reference_constants_loaded: false

## Checks

| check | value |
|---|---|
| abs_tunnel_leq_T | True |
| config_ok | True |
| csv_range_matches_config | True |
| csv_stride_mode_matches_config | True |
| depth_over_flux_matches_summary | True |
| local_r_over_flux2_median_matches_summary | True |
| reference_constants_loaded | False |
| schema_ok | True |
| zero_crossings_count_matches_summary | True |
| zero_crossings_neighborhood_matches_summary | True |

## Derived invariants (from CSV)

- depth_over_flux_p05/p50/p95: 0.5666439007906231 / 0.5666439007906231 / 0.5666439007906232
- local_r_over_flux2_p50: 12.13
- zero_crossings_count_csv: 2
- zero_crossing_intervals(n_left,n_right): [(99401, 99601), (200001, 200201)]

## Verdict

- overall_pass: true
- gating_keys: ['csv_range_matches_config', 'csv_stride_mode_matches_config', 'abs_tunnel_leq_T', 'depth_over_flux_matches_summary', 'local_r_over_flux2_median_matches_summary', 'zero_crossings_count_matches_summary']

