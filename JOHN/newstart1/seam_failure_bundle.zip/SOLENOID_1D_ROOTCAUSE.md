# Solenoid 1D FAIL Root Cause Analysis

## Purpose

Document why solenoid domain FAILs in 1D anchor validation, and how to handle it separately from 2D PASS pipeline.

## Key Decision: Exclude u50_obs <= 0 from r_u calculation

**Action**: Set `valid_for_ru=False` for rows where `u50_obs <= 0`.

This is already implemented in `fit_solenoid_anchor.py` line 114:
```python
if np.isfinite(u50_obs) and np.isfinite(u50_pred) and (u50_obs > 0):
    # ... compute r_u
    valid_for_ru = True
```

## Root Cause Classification

### (i) Curve step vs. noise confusion

**Hypothesis**: The extraction algorithm misinterprets noise-induced fluctuations as a bifurcation step, leading to negative `u50` values.

**Evidence**:
- Solenoid manifolds show hysteresis behavior
- High noise can cause false step detection
- Negative `u50` values suggest the algorithm found a "step" below the reference point

**Status**: **NOT TO FIX** - This is a fundamental limitation of step detection in noisy data. The exclusion (`valid_for_ru=False`) is the correct handling.

### (ii) Incorrect u-axis reference

**Hypothesis**: The `u50` definition assumes a positive reference point, but solenoid's bifurcation structure may have a different zero point or sign convention.

**Evidence**:
- Other domains (chemistry, hydrology) have positive `u50` values
- Solenoid's magnetic field/current relationship may have a different sign convention
- The anchor fitting assumes `u50 > 0` for normalization

**Status**: **TO INVESTIGATE** - If solenoid's physics requires a different sign convention, we may need domain-specific `u50` extraction logic. However, for now, exclusion is acceptable.

### (iii) Forced sign consistency for u50

**Hypothesis**: The universal anchor model assumes all domains have the same sign convention for `u50`, but solenoid may naturally produce negative values in some configurations.

**Evidence**:
- The 2D anchor model uses `u50` as a positive quantity for normalization
- `r_u = (u50_obs - u50_pred) / max(abs(u50_pred), u_min)` requires a meaningful sign
- If `u50_obs < 0` and `u50_pred > 0`, the residual sign is ambiguous

**Status**: **NOT TO FIX** - The exclusion is correct. We should not force sign consistency across domains if it violates physics.

## Implementation Details

### Current behavior in `fit_solenoid_anchor.py`

```python
u50_obs_nonpos = (not np.isfinite(u50_obs)) or (u50_obs <= 0)
# ...
valid_for_ru = False
if np.isfinite(u50_obs) and np.isfinite(u50_pred) and (u50_obs > 0):
    denom_u = max(abs(u50_pred), u_min_used)
    if denom_u > 0:
        r_u = (u50_obs - u50_pred) / denom_u
        valid_for_ru = True
```

### Threshold calculation

Thresholds `T_w` and `T_u` are computed using **only valid rows** (`valid_for_rw=True` and `valid_for_ru=True`). This means:
- Rows with `u50_obs <= 0` do not contribute to `T_u` calculation
- Rows with `width_obs <= 0` do not contribute to `T_w` calculation

## Separation from 2D PASS

**Decision**: Do not integrate solenoid into the 2D PASS pipeline.

**Reasoning**:
1. Solenoid uses a 1D anchor (solenoid-specific manifold), not the universal 2D surface
2. Negative `u50` values require special handling that breaks the universal normalization
3. The 2D PASS is for domains that can be mapped to `u50*(noise, t_end)` surface
4. Solenoid's physics may require domain-specific treatment

## Recommendations

### Items to Fix (if needed)

1. **Domain-specific u50 extraction**: If solenoid's physics requires a different sign convention, implement domain-specific extraction logic in `extract_universality_features.py` or similar.

2. **Documentation**: Ensure all scripts that process solenoid data explicitly document the `u50_obs <= 0` exclusion.

### Items NOT to Fix

1. **Exclusion logic**: The `valid_for_ru=False` for `u50_obs <= 0` is correct and should remain.

2. **Universal anchor assumption**: Do not force all domains to have positive `u50` if it violates physics.

3. **2D integration**: Do not force solenoid into the 2D PASS pipeline.

## Summary

| Issue | Root Cause | Action | Status |
|-------|------------|--------|--------|
| Negative u50_obs | Noise/step confusion, sign convention | Exclude from r_u (`valid_for_ru=False`) | ✅ Implemented |
| Solenoid FAIL | Domain-specific physics | Keep separate from 2D PASS | ✅ Decision made |
| Sign consistency | Physics-based | Do not force | ✅ Correct |

## Next Steps

1. Continue using `fit_solenoid_anchor.py` with exclusion logic for negative `u50_obs`.
2. If solenoid validation is required, use domain-specific thresholds and criteria.
3. Do not attempt to integrate solenoid into `fit_2d_surface_anchor_A.py` pipeline.
