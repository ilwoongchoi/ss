# ATLAS V2.2 EVIDENCE CERTIFICATE

**Generated:** 2026-02-16T01:09:14.636102  
**Atlas Version:** V2.2  
**Certificate Type:** EVIDENCE_LOCK

---

## 1. EVIDENCE PACKET HASH

| Property | Value |
|----------|-------|
| File | `PI_ATLAS_V2.2_EVIDENCE_PACKET.zip` |
| SHA256 | `5652937b513a027dd9787d58d47cb2c54c1b6cb47e67886b3f52f956339c22db` |
| Size | 16,411 bytes |

---

## 2. SHA256 MANIFEST

| Filename | SHA256 | Size (bytes) |
|----------|--------|--------------|
| `atlas_registry.csv` | `6bc9771370a3aae77324cfba9b8b16df671702ddeda72bc9a7549ba6e0f27177` | 3,838 |
| `atlas_boundary_band_long.csv` | `288baf6e7bb0a1a2e183a7413325a27dc764977bd598070d5cfe8c443b166cc9` | 25,121 |
| `atlas_contact_pairs_long.csv` | `faacaee7277b30f90d2b6dbf07ca72ad0fa1a8a96f12dd215449f732b3041b38` | 720 |
| `atlas_gap_pairs_long.csv` | `b810d2b76e9c4069d990d2b2e5d5b8da18029aa67b05750def8b331f48f8e75a` | 5,491 |
| `atlas_hubness_long.csv` | `a9fad5f2eb50c9be667f1edd971f5e1647ca0de3dbcfd1a3638d3b75aa849fb9` | 3,543 |
| `atlas_ridge_neckband_long.csv` | `b65055eeb478a01de1115741e8755fd97c3798004ea5596a7ce1451b76ceb53a` | 34,876 |
| `UNIVERSAL_CORE_v2.2.json` | `cdc110ace9d99afb77cf78186189b27bfb362f2de39863a4ff77604ae0b087d0` | 7,790 |

**SHA256_MANIFEST_v2.2.csv Hash:** `508491f956191bd6b71b68dc30da33969ec99c08d86079a8f074c124d2b315e3`

---

## 3. DOMAINS INCLUDED

| Domain | n_packets | boundary_band | contact_pairs | gap_pairs | hubness | ridge_neckband |
|--------|-----------|---------------|---------------|-----------|---------|----------------|
| bbj_gwas | 1 | 20 | 1 | 1 | 2 | 19 |
| circadian | 1 | 25 | 0 | 0 | 1 | 42 |
| co2 | 1 | 20 | 0 | 21 | 7 | 24 |
| cpcsoil | 1 | 37 | 1 | 1 | 2 | 34 |
| gistemp | 1 | 20 | 3 | 3 | 3 | 19 |
| iris | 1 | 20 | 1 | 10 | 5 | 16 |
| korea_wq | 1 | 25 | 3 | 10 | 5 | 22 |
| korea_wq_bodcod | 1 | 25 | 2 | 10 | 5 | 22 |
| korea_wq_tntp | 1 | 25 | 3 | 10 | 5 | 22 |
| maxwell | 1 | 16 | 0 | 0 | 1 | 17 |
| mito_leak | 1 | 11 | 1 | 1 | 2 | 8 |
| oisst | 1 | 19 | 0 | 0 | 1 | 16 |
| sh | 1 | 55 | 0 | 0 | 1 | 47 |

**Total Domains:** 13

---

## 4. GLOBAL STATISTICS

| Metric | Value |
|--------|-------|
| total_boundary_band_records | 318 |
| total_contact_pairs | 15 |
| total_gap_pairs | 67 |
| total_hubness_records | 40 |
| total_ridge_neckband_records | 308 |
| n_domains_with_boundary | 13 |
| n_domains_with_contact | 8 |
| n_domains_with_gap | 9 |
| n_domains_with_hubness | 13 |
| n_domains_with_ridge | 13 |

---

## 5. DETERMINISM VERIFICATION

**Status:** VERIFIED

The ATLAS V2.2 evidence packet has been verified for deterministic reproducibility:
- Same input cert packets (21 FULL, 1 AUX)
- Same ingestion and cleaning logic applied twice
- Result: Identical SHA256 hashes for all output files byte-for-byte

**Verification Method:**
1. First run computed SHA256 for all 7 output files
2. Second run recomputed SHA256 for all 7 output files
3. All hashes matched exactly

---

## 6. CERTIFICATION

This certificate attests that the PI_ATLAS_V2.2_EVIDENCE_PACKET.zip contains:
- 13 unique domain packets (deduplicated from 21 raw FULL packets)
- Cleaned and normalized geometry artifacts
- Deterministically reproducible outputs

**Certified By:** ATLAS Integrator Agent  
**Certification Date:** 2026-02-16T01:09:14.638100

---

*End of Certificate*
