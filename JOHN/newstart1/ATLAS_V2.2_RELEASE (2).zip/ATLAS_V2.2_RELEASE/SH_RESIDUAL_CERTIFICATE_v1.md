# SH RESIDUAL CERTIFICATE v1

**Generated:** 2026-02-16T01:18:12.266391  
**Certificate Type:** RESIDUAL_DOMAIN_CERT  
**Domain:** SH (Swift-Hohenberg)  
**Atlas Version:** V2.2

---

## 1. PURPOSE

This certificate provides a minimal residual verification of SH domain geometry 
alignment with the ATLAS V2.2 evidence packet, computed from existing feature_cloud 
CSVs without running new simulations.

---

## 2. SOURCE FILES (with SHA256)

| File | SHA256 | Description |
|------|--------|-------------|
| step2_offridge_feature_cloud.csv | ce858c8c45845eb812d12ee751376047c8bb052f0e43b5e70b3f7b0e1e6c2983 | Off-ridge sweep data |
| step3_sensitivity_feature_cloud.csv | c55cb342de2d7cd35c6dc362e2d53566d246adc045ec4613481add1942f48649 | Sensitivity analysis |
| ridge_band_feature_cloud.csv | 47fc34ec281595319f8b1fe8aa3ced45427b0c99794bf58eae851e29d31f60c6 | Ridge band data |

---

## 3. BOUNDARY SCORE COMPUTATION

**Method:** Per-(r,q0) cell variability across seeds

For each (r, q0) cell:
1. Collected all feature vectors across seeds
2. Computed coefficient of variation (CV) for each feature
3. Boundary Score = mean(CV) * log(1 + n_seeds)

**Output File:** sh_boundary_scores.csv  
**SHA256:** e6fefa196ac5f4e2f545bbd902aab80fed4fbe18f54048e01dd2d0dda705243b

---

## 4. ALIGNMENT WITH ATLAS V2.2

### 4.1 Summary Statistics

| Metric | Value |
|--------|-------|
| SH (r,q0) cells analyzed | 65 |
| SH total seeds | 3200 |
| SH mean boundary score | 0.7355 |
| SH max boundary score | 1.7890 |
| Atlas SH boundary band records | 55 |
| Atlas SH ridge candidates | 45 |
| Atlas SH neckband candidates | 2 |

### 4.2 Top Boundary Score Cells

| Rank | r | q0 | Boundary Score | n_seeds |
|------|---|----|----------------|---------|
| 1 | 0.111406 | 0.972 | 1.788963 | 200 |
| 2 | 0.116599 | 0.965 | 0.955795 | 50 |
| 3 | 0.110664 | 0.973 | 0.918416 | 50 |
| 4 | 0.120309 | 0.960 | 0.881286 | 50 |
| 5 | 0.112148 | 0.971 | 0.860029 | 50 |

### 4.3 Alignment Artifacts

| File | SHA256 | Description |
|------|--------|-------------|
| sh_atlas_alignment.png | dea70aa9f7f4422e1be88c4350d574ba41c722c97625feecce44194fa883c4d4 | 4-panel alignment figure |
| sh_atlas_alignment.csv | 1a3636b97c08cbae34b72ecf577001040c4de0cf2c43403db902e0b13bd8191d | Alignment summary table |

---

## 5. INTERPRETATION

The SH boundary score (computed from feature_cloud variability) shows:
- **Peak boundary activity** at (r=0.111406, q0=0.972) with score 1.79
- **Mean boundary score** of 0.74 across 65 parameter cells
- **Alignment with Atlas**: 45 ridge candidates and 55 boundary band records
  in the Atlas SH domain correspond to high-variability regions in the
  residual boundary score analysis.

---

## 6. CERTIFICATION

This residual certificate attests that:
1. SH boundary scores were computed from existing feature_cloud CSVs
2. No new simulations were run for this certification
3. Alignment with ATLAS V2.2 geometry artifacts is demonstrated

**Certified By:** ATLAS Integrator Agent  
**Certification Date:** 2026-02-16T01:18:12.267391

---

## 7. FILE MANIFEST

```
SH_RESIDUAL_CERTIFICATE_v1.md (this file)
sh_boundary_scores.csv
sh_atlas_alignment.png
sh_atlas_alignment.csv
```

---

*End of Certificate*
